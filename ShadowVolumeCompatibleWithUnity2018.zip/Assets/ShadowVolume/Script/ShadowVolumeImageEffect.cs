﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ShadowVolumeImageEffect
{
    void DrawImageEffect(RenderTexture source, RenderTexture destination);
}
